@extends('layout.layout')
@section('content')

<div class="row">
  <div class="col-md-12 py-2">
    <h3>Dashboard</h3>
  </div>
</div>

@endsection