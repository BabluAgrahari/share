
<?php $__env->startSection('content'); ?>

<div class="card-header py-2 h-body">
    <div class="row">
        <div class="col-md-6 pt-1">
            <h6 class="m-0 font-weight-bold text-primary">User</h6>
        </div>

        <div class="col-md-6 text-right">
            <?php if(!empty($filter)): ?>
            <a href="javascript:void(0);" class="btn btn-sm btn-outline-warning" id="filter-btn"><span class="mdi mdi-filter-outline-remove"></span>&nbsp;Close</a>
            <?php else: ?>
            <a href="javascript:void(0);" class="btn btn-sm btn-outline-primary" id="filter-btn"><span class="mdi mdi-filter-outline"></span>&nbsp;Filter</a>
            <?php endif; ?>
            <a href="<?php echo e(url('user/create')); ?> " class="btn btn-success btn-sm"><span class="mdi mdi-plus"></span>&nbsp;Add</a>
        </div>
    </div>
</div>
<div class="row mt-2 pl-2 pr-2" id="filter" <?= (empty($filter)) ? "style='display:none'" : "" ?>>
    <div class="col-md-12 ml-auto">
        <form action="<?php echo e(url('user')); ?>">
            <div class="form-row">

                <div class="form-group col-md-2">
                    <label>Date Range</label>
                    <input type="text" class="form-control form-control-xs daterange" value="<?= !empty($filter['date_range']) ? $filter['date_range'] : dateRange() ?>" name="date_range" />
                </div>

                <div class="form-group col-md-2">
                    <label>Name:</label>
                    <input type="text" class="form-control form-control-xs" name="name" value="<?php echo e(!empty($filter['name']) ? $filter['name'] : ''); ?>" placeholder="Enter Name">
                </div>

                <div class="form-group col-md-2">
                    <label>Email:</label>
                    <input type="text" class="form-control form-control-xs" name="email" value="<?php echo e(!empty($filter['email']) ? $filter['email'] : ''); ?>" placeholder="Enter Email">
                </div>

                <div class="form-group col-md-2">
                    <label>Phone No:</label>
                    <input type="text" class="form-control form-control-xs" name="mobile" value="<?php echo e(!empty($filter['mobile']) ? $filter['mobile'] : ''); ?>" placeholder="Enter Phone No">
                </div>


                <div class="form-group col-md-2">
                    <label>Status</label>
                    <select class="form-control form-control-xs" name="status">
                        <option value="">All</option>
                        <option value="1" <?= (!empty($filter['status']) && $filter['status'] == '1') ? 'selected' : '' ?>>Active</option>
                        <option value="0" <?= (isset($filter['status']) && $filter['status'] == '0') ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </div>

                <div class="form-group mt-4">
                    <button type="submit" class="btn btn-success btn-sm"><i class="fa fa-search"></i>&nbsp;Search</button>
                    <a href="<?php echo e(url('user')); ?>" class="btn btn-warning btn-sm"><i class="mdi mdi-eraser-variant"></i>&nbsp;Clear</a>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="p-2 table-responsive">
    <table class="w-100 table table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile No.</th>
                <th>City</th>
                <th>State</th>
                <th>Pin</th>
                <th>Address</th>
                <th>Role</th>
                <th>Address</th>
                <th colspan="2" class="text-center">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$key); ?></td>
                <td><?php echo e(ucwords($list->name)); ?></td>
                <td><?php echo e($list->email); ?></td>
                <td><?php echo e($list->mobile); ?></td>
                <td><?php echo e($list->city); ?></td>
                <td><?php echo e($list->state); ?></td>
                <td><?php echo e($list->pin); ?></td>
                <td><?php echo e($list->address); ?></td>
                <td><?php echo e(ucwords($list->role)); ?></td>
                <td><?php echo e($list->address); ?></td>
                <td>
                    <?= $list->status == 1 ? '<a href="javascript:void(0)">
                <span class="activeVer badge badge-outline-success" _id="' . $list->id . '" val="0">Active</span>
                </a>'
                        : '<a href="javascript:void(0);">
                <span class="activeVer badge badge-outline-warning" _id="' . $list->id . '" val="1">Inactive</span>
                </a>' ?>
                </td>
                <td>
                    <a href="user/<?php echo e($list->id); ?>/edit" class="btn btn-sm btn-outline-info"><span class="mdi mdi-pencil-box-outline"></span></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
    <?php echo e($lists->appends($_GET)->links()); ?>

</div>
<?php $__env->startPush('script'); ?>
<script>
    $(document).on('click', '.activeVer', function() {
        var id = $(this).attr('_id');
        var val = $(this).attr('val');
        var selector = $(this);
        $.ajax({
            'url': "<?php echo e(url('user-status')); ?>",
            data: {
                "_token": "<?php echo e(csrf_token()); ?>",
                'id': id,
                'status': val
            },
            type: 'POST',
            dataType: 'json',
            success: function(res) {
                if (res.val == 1) {
                    $(selector).text('Active').attr('val', '0').removeClass('badge-outline-warning').addClass('badge-outline-success');
                } else {
                    $(selector).text('Inactive').attr('val', '1').removeClass('badge-outline-success').addClass('badge-outline-warning');
                }
                Swal.fire(
                    `${res.status}!`,
                    res.msg,
                    `${res.status}`,
                )
            }
        })

    })
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\htdocs_old\share\resources\views/user/index.blade.php ENDPATH**/ ?>