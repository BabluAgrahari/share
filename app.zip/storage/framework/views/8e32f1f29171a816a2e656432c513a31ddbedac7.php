<div class="row">
    <div class="col-md-12">
        <?php if(Session::has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(Session::get('success')); ?>

            <?php
            Session::forget('success');
            ?>
        </div>
        <?php elseif(Session::has('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(Session::get('error')); ?>

            <?php
            Session::forget('error');
            ?>
        </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\htdocs_old\share\resources\views/include/conf_respinse.blade.php ENDPATH**/ ?>