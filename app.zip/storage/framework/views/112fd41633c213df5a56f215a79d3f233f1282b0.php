
<?php $__env->startSection('content'); ?>

<div class="card-header py-2 h-body">
    <div class="row">
        <div class="col-md-6 pt-1">
            <h6 class="m-0 font-weight-bold text-primary">Add Client</h6>
        </div>

        <div class="col-md-6">
            <a href="<?php echo e(url('client')); ?>" class="btn btn-warning btn-sm" style="float:right;"><span class="mdi mdi-backburger"></span>&nbsp;Back</a>
        </div>
    </div>
</div>

<div class="card-body h-body">
    <div class="row">
        <div class="col-md-12">

            <form action="<?php echo e(url('client')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <!-- <h6>Client Details</h6>
                    <hr> -->
                    <div class="form-group col-md-3">
                        <label>File No(Manual)</label>
                        <input type="text" class="form-control form-control-sm" value="<?php echo e(old('file_no')); ?>" placeholder="Enter File No" name="file_no">
                        <?php $__errorArgs = ['file_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group col-md-3">
                        <label>Folio No</label>
                        <input type="text" class="form-control form-control-sm" value="<?php echo e(old('folio_no')); ?>" placeholder="Enter Folio No" name="folio_no">
                        <?php $__errorArgs = ['folio_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group col-md-3">
                        <label>Share Holder</label>
                        <input type="text" class="form-control form-control-sm" value="<?php echo e(old('share_holder')); ?>" placeholder="Enter Share Holder" name="share_holder">
                        <?php $__errorArgs = ['share_holder'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group col-md-3">
                        <label>Survivor Name</label>
                        <input type="text" class="form-control form-control-sm" value="<?php echo e(old('survivor_name')); ?>" placeholder=" Enter Survivor Name" name="survivor_name">
                        <?php $__errorArgs = ['survivor_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-3">
                        <label>SRN</label>
                        <input type="text" class="form-control form-control-sm" value="<?php echo e(old('srn')); ?>" placeholder="Enter SRN" name="srn">
                        <?php $__errorArgs = ['srn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group col-md-3">
                        <label>Date</label>
                        <input type="date" class="form-control form-control-sm" value="<?php echo e(old('date')); ?>" placeholder="Enter Date" name="date">
                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-md-3">
                        <label>Select Court</label>
                        <select class="form-control form-control-sm" value="<?php echo e(old('court_id')); ?>" placeholder="Enter Court Name" name="court_id">
                            <option value="">Select</option>
                            <?php $__currentLoopData = $courts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($list->id); ?>"><?php echo e(ucwords($list->court_name)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['court_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-3">
                        <label>City</label>
                        <input type="text" class="form-control form-control-sm" value="<?php echo e(old('city')); ?>" placeholder="Enter City" name="city">
                        <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group col-md-2">
                        <label value="">State</label>
                        <select class="form-control form-control-sm" placeholder="Enter State" name="state">
                            <option value=" ">Select</option>
                            <?php $__currentLoopData = config('global.state'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($state); ?>"><?php echo e($state); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group col-md-2">
                        <label>Pin</label>
                        <input type="text" class="form-control form-control-sm" value="<?php echo e(old('pin')); ?>" placeholder="Enter Pin Code" name="pin">
                        <?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group col-md-5">
                        <label>Address</label>
                        <textarea type="text" class="form-control form-control-sm" placeholder="Enter Address" name="address"><?php echo e(old('address')); ?></textarea>
                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>

                <div class="row">
                    <div class="form-group col-md-6">
                        <label>Remark</label>
                        <textarea name="remarks" class="form-control form-control-sm" placeholder="Enter Remark" rows="3"><?php echo e(old('remarks')); ?></textarea>
                    </div>
                </div>

                <div class="row">
                    <!-- <h6><i class="mdi mdi-account-circle menu-icon"></i>Contact Person Details</h6>
                    <hr> -->
                    <div class="form-group col-md-3">
                        <label>Contant Person Name</label>
                        <input type="text" class="form-control form-control-sm" name="cp_name" value="<?php echo e(old('cp_name')); ?>" placeholder="Contact Person Name">
                        <?php $__errorArgs = ['cp_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group col-md-3">
                        <label>Email</label>
                        <input type="email" class="form-control form-control-sm" name="cp_email" value="<?php echo e(old('cp_email')); ?>" placeholder="Enter Email">
                        <?php $__errorArgs = ['cp_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group col-md-3">
                        <label>Mobile</label>
                        <input type="text" class="form-control form-control-sm" name="cp_mobile" value="<?php echo e(old('cp_mobile')); ?>" placeholder="Enter Mobile">
                        <?php $__errorArgs = ['cp_mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group col-md-3">
                        <label>Designation </label>
                        <input type="text" class="form-control form-control-sm" value="<?php echo e(old('cp_designation')); ?>" placeholder=" Enter Designation	" name="cp_designation">
                        <?php $__errorArgs = ['cp_designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="row mb-2">
                    <!-- <h6>Company Details</h6> -->
                    <!-- <hr> -->
                    <div class="company-table">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Company Name</th>
                                    <th>Share Qty</th>
                                    <th>Type</th>
                                    <th>Transfer Agent</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="field_wrapper">
                                <tr>
                                    <td class="w-25">
                                        <select id="company_name" selector="0" class="form-control form-control-xs" required name="company[0][company_id]">
                                            <option value="">Select</option>
                                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($list->id); ?>"><?php echo e(ucwords($list->company_name)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>

                                    <td class="w-25">
                                        <input type="number" class="form-control form-control-xs" required name="company[0][unit]" placeholder="Enter Qty">
                                    </td>

                                    <td class="w-20">
                                        <select class="form-control form-control-xs" required name="company[0][type]">
                                            <option value="">Select</option>
                                            <option value="type1">Type1</option>
                                            <option value="type2">Type2</option>
                                            <option value="type3">Type3</option>
                                            <option value="type4">Type4</option>
                                            <option value="type5">Type5</option>
                                        </select>
                                    </td>

                                    <td class="w-25">
                                        <select class="form-control form-control-xs" id="agent-id-0" required placeholder="Select Contant" name="company[0][agent_id]">
                                            <option value="">Select</option>

                                        </select>
                                    </td>
                                    <td>
                                        <a href="javascript:void(0)" id="add_more" class="btn btn-xs btn-success"><span class="mdi mdi-plus"></span></a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="form-group text-center">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    var i = 1;
    $('#add_more').click(function() {
        var vendor_id = $(this).attr('vendor_id');
        var fieldHTML = `<tr id="row-${i}">
                                <td class="w-25">
                                    <select id="company_name" class="form-control selector="${i}" form-control-xs" required name="company[${i}][company_id]">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($list->id); ?>"><?php echo e(ucwords($list->company_name)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>

                                <td class="w-25">
                                    <input type="number" class="form-control form-control-xs" required name="company[${i}][unit]" placeholder="Enter Qty">
                                </td>

                                <td class="w-20">
                                    <select class="form-control form-control-xs" required name="company[${i}][type]">
                                        <option value="">Select</option>
                                        <option value="type1">Type1</option>
                                        <option value="type2">Type2</option>
                                        <option value="type3">Type3</option>
                                        <option value="type4">Type4</option>
                                        <option value="type5">Type5</option>
                                    </select>
                                </td>

                                <td class="w-25">
                                    <select class="form-control form-control-xs" placeholder="Select Contant" required name="company[${i}][agent_id]">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($list->id); ?>"><?php echo e(ucwords($list->transfer_agent)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                                <td>
                                <a href="javascript:void(0)" onClick="removeRow(${i});" class="btn btn-xs btn-danger"><span class="mdi mdi-delete-forever"></span></a>
                                </td>
                            </tr>`;

        $('#field_wrapper').append(fieldHTML);
        i++;
    });

    function removeRow(id) {
        var element = document.getElementById("row-" + id);
        element.parentNode.removeChild(element);
    }

    $(document).on('change', '#company_name', function() {
        let company_id = $(this).val();
        let selector = $(this).attr('selector');
        $.ajax({
            url: "<?php echo e(url('client/find-agent')); ?>/" + company_id,
            type: "GET",
            dataType: "JSON",
            success: function(res) {

                $('#agent-id-' + selector).html(res);
            }
        })
    });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\htdocs_old\share\resources\views/client/create.blade.php ENDPATH**/ ?>